import random
import json
from datetime import datetime

class XO:
    def __init__(self):
        self.board = []
        self.size = 3
        self.stats_file = "статистика.json"
        self.stats = self.load_stats()
        self.current_player = ""
    
    def load_stats(self):
        try:
            with open(self.stats_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"игр_сыграно": 0, "крестики": 0, "нолики": 0, "ничьи": 0}
    
    def save_stats(self, winner):
        self.stats["игр_сыграно"] += 1
        
        if winner == "X":
            self.stats["крестики"] += 1
            win_text = "Крестики"
        elif winner == "O":
            self.stats["нолики"] += 1
            win_text = "Нолики"
        else:
            self.stats["ничьи"] += 1
            win_text = "Ничья"
        
        
        with open(self.stats_file, 'w', encoding='utf-8') as f:
            json.dump(self.stats, f, indent=2, ensure_ascii=False)
    
    def get_size(self):
        while True:
            try:
                size = int(input("Размер поля (3-5): "))
                if 3 <= size <= 5:
                    return size
            except:
                print("Введите число 3-5")
    
    def init_board(self, size):
        self.size = size
        self.board = [str(i+1) for i in range(size*size)]
    
    def draw(self):
        size = self.size
        print("\n" + "-"*(size*4+1))
        for i in range(size):
            row = self.board[i*size:(i+1)*size]
            print("| " + " | ".join(row) + " |")
            print("-"*(size*4+1))
    
    def choose_first(self):
        self.current_player = random.choice(["X", "O"])
        print(f"\nПервым ходит: {self.current_player}")
        return self.current_player
    
    def move(self, player):
        while True:
            try:
                pos = int(input(f"Игрок {player}, ваш ход (1-{len(self.board)}): "))
                if 1 <= pos <= len(self.board) and self.board[pos-1] not in "XO":
                    self.board[pos-1] = player
                    return
                print("Неверный ход")
            except:
                print("Введите число")
    
    def check_win(self):
        size = self.size
        
        for i in range(size):
            row = self.board[i*size:(i+1)*size]
            if all(cell == row[0] for cell in row) and row[0] in "XO":
                return row[0]
        
        for i in range(size):
            col = [self.board[i + j*size] for j in range(size)]
            if all(cell == col[0] for cell in col) and col[0] in "XO":
                return col[0]
        
        diag1 = [self.board[i*size + i] for i in range(size)]
        if all(cell == diag1[0] for cell in diag1) and diag1[0] in "XO":
            return diag1[0]
        
        diag2 = [self.board[i*size + (size-1-i)] for i in range(size)]
        if all(cell == diag2[0] for cell in diag2) and diag2[0] in "XO":
            return diag2[0]
        
        if all(cell in "XO" for cell in self.board):
            return "draw"
        
        return None
    
    def play(self):
        size = self.get_size()
        self.init_board(size)
        player = self.choose_first()
        
        while True:
            self.draw()
            self.move(player)
            
            result = self.check_win()
            if result:
                self.draw()
                if result == "draw":
                    print("\nНичья!")
                    self.save_stats("draw")
                else:
                    print(f"\nВыиграл {result}!")
                    self.save_stats(result)
                break
            
            player = "O" if player == "X" else "X"
    
    def show_stats(self):
        print(f"Игр сыграно: {self.stats['игр_сыграно']}")
        print(f"Крестики выиграли: {self.stats['крестики']}")
        print(f"Нолики выиграли: {self.stats['нолики']}")
        print(f"Ничьих: {self.stats['ничьи']}")
        
    
    def menu(self):
        while True:
            print("1. Новая игра")
            print("2. Статистика")
            print("3. Выход")
            
            choice = input("Выберите: ")
            
            if choice == "1":
                self.play()
                input("\nНажмите Enter...")
            elif choice == "2":
                self.show_stats()
                input("\nНажмите Enter...")
            elif choice == "3":
                print("Выход")
                break

if __name__ == "__main__":
    game = XO()
    game.menu()